def helloworld(event, context):
    print("Hello World")