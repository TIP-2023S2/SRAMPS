def hello(event, context):
    print("Hello World!!")
